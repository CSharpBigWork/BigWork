﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OurWork2
{
    public class EventDetails
    {
        public int eventId { set; get; }
        public string eventName { set; get; }
        public DateTime createTime { set; get; }
        public string courseName { set; get; }
    }
}

